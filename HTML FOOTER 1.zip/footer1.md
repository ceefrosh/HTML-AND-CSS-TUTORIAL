HTML
In the html file,use the footer tag as the parent container 
Use footer heading class for the div to nest ur UL
Finally use font awesome and Google fonts to get social media icons 
CSS
USE universal selector * to set the css margin and padding 
* {
	margin padding box sizing 
BODY
set the display properties 
flex wrap, margin top ,padding, line height, bgcolor  list style,
position, font weight,font size, text transform,

PSUEDO CLASS
content
position 
left right bottom top
height width
display , colorr ,text-decoration ,
text transform , a::hover, 
